Steps to Use.

Pre-Requisites - 
a. Refer Biometric_API_Specification_V2_20.pdf which explains the Morpho API specification for user's better understanding in terms of use.



1. Launch "setup.exe" version 2.20.6.14
2. All dlls and services will be installed at "C:\FingerprintSensors\SMARTCHIP_APPLETLESS"
3. Open "MorphoTestPage_https.html" and check morpho functionalities.
4. By default 15000 port is set in config file. User can change the port during installation.

